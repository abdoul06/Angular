import { Injectable } from '@angular/core';


@Injectable({
    providedIn: 'root'
})
export class BookService {
    //URL for CRUD operations
    
    //Create constructor to get Http instance
    
    //Fetch all books
   
    //Create book
    
       
    
    //Fetch book by id
    
    //Update book
  
    //Delete book	
    
}